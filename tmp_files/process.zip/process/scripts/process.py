from pxz import algo
from pxz import scene
from pxz import scenario
from pxz import core
from os.path import splitext,join,basename
import time

def getIDName(occurrence):
	name = core.getProperty(occurrence,"Name")
	Id = core.getProperty(occurrence,"Id")
	IDName = "[" + Id + "] " + name
	return IDName

def getChildOccurrences(Occurrence,all_occurrences):
    many = scene.getChildren(Occurrence)	
    if(many):
        all_occurrences.extend(many)
        for i in many:
            getChildOccurrences(i,all_occurrences)

def exportDefinitionOccurrence(target,all_occurrences,raw_time,outputDirectory,outputFormat):
    all_occurrences.append(target)
    getChildOccurrences(target,all_occurrences)
    #对每个子节点，进行有无Definition的判断
    for occurrence in all_occurrences:
        metadata = scene.getComponent(occurrence, 5) 
        if(metadata):
            try:
                definition = scene.getMetadata(metadata,"Definition")
                print("当前的节点的描述信息：",definition)
                scene.clearSelection()
                scene.select([occurrence])
                targetName = core.getProperty(target, "Name") 
                IDName = getIDName(occurrence)
                fileName = IDName + "." + outputFormat                    
                filePath = join(outputDirectory,raw_time,targetName,fileName)
                print("当前节点的路径信息：",filePath)
                io.exportSelection(filePath)
            except:
                print("当前节点有Metadata组件，但是没有definition")
        else:
            print("当前选中节点没有Metadata组件")


def process(isExportDefinitionOccurrence,
            input,occurrences,
            maxSag,maxAngle,
            resolution,sphereCount,
            Tolerance,
            TargetStrategy,BoundaryWeight,NormalWeight,UVWeight,SharpNormalWeight,UVSeamWeight,ForbidUVFoldovers,ProtectTopology,
            decimateParametersList,
            outputDirectory,fileFormat):
    raw_time = time.strftime("%Y-%m-%d, %H-%M-%S", time.localtime())
    root = scene.getRoot() 
    #!没有选中并导入了新文件且新文件没在场景中出现过   [新文件]  +
    #!没有选中并导入了新文件但新文件在场景中出现过   []  +
    #!选中了也导入了新文件    [选中，新文件]  +
    #!选中了也导入了新文件但新文件已经在场景中出现过    [选中]  +
    #!没有选中也没导入新文件   [root的所有孩子] +
    #!选中了但没导入新文件   [选中] 
    if(input):
        #*获取输入的文件名         
        input_fileName = basename(input)
        #*从场景中获取根节点，得到其所有的子节点，
        childs = scene.getChildren(root)
        #判断场景中是否已经有同一个文件
        flag = True
        for child in childs:
            childName = core.getProperty(child, "Name")
            if(childName == input_fileName):
                #不导入
                flag = False
                occurrences = []#场景中已经有了该模型 则不对场景进行操作
                break
        #如果场景中没有这个将要导入的文件就导入后找到它
        #因为导入了新的文件，所以如果原来没有选中的话需要把默认root的occurrences列表置空
        if(flag == True):
            #没选中则清空列表
            if(occurrences == [root]):
                occurrences = []
            io.importScene(input)
            childs = scene.getChildren(root)
            #通过名字相同来找到导入的节点ID，并对其进行操作
            for child in childs:
                childName = core.getProperty(child, "Name")
                if(childName == input_fileName):
                    occurrences.append(child)            
        #occurrences必须是root下的场景中的所有结构而不是root
    else:#没导入新文件
        if(occurrences == [root]):
            occurrences = scene.getChildren(root)
    for occurrence in occurrences:
        #Step1 执行CAD细分    
        algo.tessellate([occurrence],maxSag,-1.000000,maxAngle)
        #Step2 选择隐藏并删除
        scene.clearSelection() 
        algo.hiddenSelection([occurrence],resolution,sphereCount, 90.000000, False)
        scene.deleteSelection()
        #Step3 执行修复网格
        algo.repairMesh([occurrence],Tolerance)
        #Step4 执行目标减面
        algo.decimateTarget([occurrence],TargetStrategy,NormalWeight,BoundaryWeight,SharpNormalWeight,UVWeight,UVSeamWeight,ForbidUVFoldovers,ProtectTopology)
        #Step5 执行生成LOD
        scenario.generateLODChain([occurrence],decimateParametersList)
        #导出
        scene.clearSelection()
        IDName = getIDName(occurrence)
        (name,ext) = splitext(IDName)
        if(ext == ".CATProduct"):
            fileName = name + "." + fileFormat
        else:
            fileName = IDName + "." + fileFormat
        filePath = join(outputDirectory,fileName)
        scene.select([occurrence])	
        io.exportSelection(filePath)
    print("isExportDefinitionOccurrence:",isExportDefinitionOccurrence)
    if(isExportDefinitionOccurrence == True):
        print("-------------------------------------------------------------我有执行！")
        for occurrence in occurrences:
            all_occurrences = []
            exportDefinitionOccurrence(occurrence,all_occurrences,raw_time,outputDirectory,fileFormat)
    scene.clearSelection() 
    