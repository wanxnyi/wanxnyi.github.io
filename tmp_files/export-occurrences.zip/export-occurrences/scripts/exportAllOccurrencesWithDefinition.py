from pxz import scene
from pxz import core
from os.path import join
import time


def getIDName(occurrence):
    name = core.getProperty(occurrence,"Name")
    Id = core.getProperty(occurrence,"Id")
    IDName = "[" + Id + "] " + name
    return IDName

def getChildOccurrences(Occurrence,all_occurrences):
    many = scene.getChildren(Occurrence)	
    if(many):
        all_occurrences.extend(many)
        for i in many:
            getChildOccurrences(i,all_occurrences)

def exportAllOccurrencesWithDefinition(outputDirectory,outputFormat):
    raw_time = time.strftime("%Y-%m-%d, %H-%M-%S", time.localtime())
    childs = scene.getSelectedOccurrences() 
	#选择列表为空时
    if(childs == []):
        root = scene.getRoot()#根节点的ID
        childs = scene.getChildren(root)#场景中所有的模型的ID的列表
    print("-------------------childs:",childs)
    for child in childs:
        #获得当前模型的所有子节点
        all_occurrences = []
        getChildOccurrences(child,all_occurrences)
        if(child not in all_occurrences):
            print("------------------------------------------------------------------------------自己不被包含在自己的所有孩子节点中")
        #对每个子节点，进行有无Definition的判断
        for occurrence in all_occurrences:
            metadata = scene.getComponent(occurrence, 5) 
            if(metadata):
                try:
                    definition = scene.getMetadata(metadata,"Definition")
                    print("当前的节点的描述信息：",definition)
                    scene.clearSelection()
                    scene.select([occurrence])
                    IDName = getIDName(occurrence)
                    fileName = IDName + "." + outputFormat                    
                    filePath = join(join(outputDirectory,raw_time),fileName)
                    print("当前节点的路径信息：",filePath)
                    io.exportSelection(filePath)
                except:
                    print("当前节点有Metadata组件，但是没有definition")
            else:
                print("当前选中节点没有Metadata组件")		